#!/bin/sh

#This is an example you can edit and use
#There are numerous parameters you can set, please check Help and Examples folder

./SRBMiner-MULTI --algorithm phi5 --pool eu.poolmine.xyz:8334 --wallet CeJg7p4vDameTtsocAhbGeKArwnwv89Jhz --password c=CBE
