#!/bin/sh

#This is an example you can edit and use
#There are numerous parameters you can set, please check Help and Examples folder

#RPLANT
./SRBMiner-MULTI --disable-gpu --algorithm curvehash --pool stratum-eu.rplant.xyz:7058 --wallet curvehashcoin-wallet-here

