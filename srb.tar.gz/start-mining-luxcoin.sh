#!/bin/sh

#This is an example you can edit and use
#There are numerous parameters you can set, please check Help and Examples folder

./SRBMiner-MULTI --disable-gpu --algorithm rx2 --pool pool.letshash.it:9009 --wallet LezrEuXhSA6qSP3cAAnsg56brVzb5PQox4
